import random
import json
import time
import os
import string

# Load agent names, keywords, and responses from an external JSON file
def load_config(file_path):
    try:
        with open(file_path, 'r') as file:
            data = json.load(file)
        return (
            data.get("agent_names", ["Default Agent"]),
            data.get("keywords", {"default": ["I'm here to help with general queries!"]}),
            data.get("random_responses", ["I'm sorry, I didn't quite get that. Can you try again?"]),
            data.get("jokes", ["Why don't skeletons fight each other? They don't have the guts!"]),
            data.get("riddles", [{"question": "What has to be broken before you can use it?", "answer": "egg"}]),
            data.get("fun_personality_traits", ["Did you know I love learning new things?"])
        )
    except FileNotFoundError:
        print("Configuration file not found!")
    except json.JSONDecodeError:
        print("Configuration file is not a valid JSON!")
    return (["Default Agent"], {"default": ["I'm here to help with general queries!"]},
            ["I'm sorry, I didn't quite get that. Can you try again?"],
            ["Why don't skeletons fight each other? They don't have the guts!"],
            [{"question": "What has to be broken before you can use it?", "answer": "egg"}],
            ["Did you know I love learning new things?"])

# Log conversation to a session file
def log_session(user_name, agent_name, chat_log):
    timestamp = time.strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"chat_log_{user_name}_{timestamp}.txt"
    try:
        with open(filename, 'w') as file:
            file.write(f"Chat session with {user_name} and agent {agent_name}\n\n")
            for entry in chat_log:
                file.write(f"{entry['type']}: {entry['message']}\n")
        print(f"Session log saved to {filename}")
    except IOError as e:
        print(f"Failed to save the log file: {e}")

# Random delay to simulate agent typing
def simulate_typing(min_delay=0.5, max_delay=1.5):
    time.sleep(random.uniform(min_delay, max_delay))

# Suggest topics or help keywords
def suggest_help(keywords):
    topics = ", ".join(keywords.keys())
    return f"I can assist with topics like {topics}. Just type a keyword or ask a related question!"

# Main chat program
def chat_program():
    # Load configuration
    config_file = "chat_config.json"
    agent_names, keywords, random_responses, jokes, riddles, fun_traits = load_config(config_file)

    # Greet user and get their name
    print("Welcome to the University of Poppleton Admissions Assistant! 🎓")
    user_name = input("Please enter your name: ").strip()
    print(f"Hello, {user_name}! Let me connect you to one of our agents. 🤖")

    # Assign random agent name
    agent_name = random.choice(agent_names)
    print(f"You are now chatting with agent {agent_name}. How can I assist you today?\n")

    chat_log = []
    while True:
        # Get user input
        user_input = input(f"{user_name}: ").strip()
        sanitized_input = user_input.translate(str.maketrans('', '', string.punctuation)).lower()
        chat_log.append({"type": "User", "message": user_input})

        # Exit conditions
        if sanitized_input in ["bye", "quit", "exit"]:
            print(f"{agent_name}: It was a pleasure assisting you, {user_name}. Have a wonderful day! 🌟")
            chat_log.append({"type": "Agent", "message": "It was a pleasure assisting you. Have a wonderful day!"})
            break

        # Help detection
        if "help" in sanitized_input or sanitized_input in ["what can you do", "options"]:
            response = suggest_help(keywords)
            simulate_typing()
            print(f"{agent_name}: {response}")
            chat_log.append({"type": "Agent", "message": response})
            continue

        # Handle jokes
        if "joke" in sanitized_input:
            if jokes:
                response = random.choice(jokes)
            else:
                response = "Sorry, I don't have any jokes right now!"
            simulate_typing()
            print(f"{agent_name}: {response} 😂")
            chat_log.append({"type": "Agent", "message": response})
            continue

        # Handle riddles
        if "riddle" in sanitized_input:
            if riddles:
                riddle = random.choice(riddles)
                simulate_typing()
                print(f"{agent_name}: Here's a riddle for you: {riddle['question']}")
                user_answer = input(f"{user_name}, what's your answer? ").strip().lower()
                if user_answer == riddle["answer"].strip().lower():
                    response = "That's correct! Well done! 🎉"
                else:
                    response = f"Oops! The correct answer was '{riddle['answer']}'. Better luck next time!"
                print(f"{agent_name}: {response}")
                chat_log.append({"type": "Agent", "message": riddle['question']})
                chat_log.append({"type": "Agent", "message": response})
            else:
                print(f"{agent_name}: Sorry, I don't have any riddles right now!")
            continue

        # Random fun personality traits
        if random.random() < 0.3:  # 30% chance
            response = random.choice(fun_traits)
            simulate_typing()
            print(f"{agent_name}: {response} 😄")
            chat_log.append({"type": "Agent", "message": response})
            continue

        # Keyword detection
        response = None
        for key, value in keywords.items():
            if key in sanitized_input:
                response = random.choice(value).replace("{name}", user_name)
                break

        # Random response if no keyword found
        if not response:
            response = random.choice(random_responses).replace("{name}", user_name)

        # Simulate typing and respond
        simulate_typing()
        print(f"{agent_name}: {response} 😊")
        chat_log.append({"type": "Agent", "message": response})

        # Random disconnection feature
        if random.random() < 0.05:  # 5% chance
            print(f"{agent_name}: Oops! I got disconnected. Please wait... 🔄")
            chat_log.append({"type": "Agent", "message": "Oops! I got disconnected. Please wait..."})
            time.sleep(3)
            print(f"{agent_name}: I'm back! Let's continue. 😅")
            chat_log.append({"type": "Agent", "message": "I'm back! Let's continue."})

    # Save session log
    log_session(user_name, agent_name, chat_log)

if __name__ == "__main__":
    chat_program()
